# WRPinfo Kodi Add-on

![logo](https://raw.githubusercontent.com/DWH-WFC/repository.wrp-metaplayer/master/icon_info.png)

***

Bei dem WRPinfo Addon handelt es sich um ein Video-Addon für Kodi, welches die Film und TV-Serien Informationen von TMDb abfragt und diese in einer GUI darstellt. In Zusammenarbeit mit dem WRP-Metaplayer die perfekte Lösung um Filme und TV Serien abspielen.

***

![logo](https://raw.githubusercontent.com/DWH-WFC/repository.wrp-metaplayer/master/resources/3.png)

![logo](https://raw.githubusercontent.com/DWH-WFC/repository.wrp-metaplayer/master/resources/4.png)

***

Original Source Code stammt von phil65

***

[![Gitter](https://badges.gitter.im/WRP-Lounge/WRP-Metaplayer.svg)](https://gitter.im/WRP-Lounge/WRP-Metaplayer?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge) Hier findet ihr Hilfe wenn es um den WRP-MetaPlayer oder WRPinfo geht.
